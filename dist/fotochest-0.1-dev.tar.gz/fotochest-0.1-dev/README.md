FotoChest
=========

http://docs.derek.stegelman.com/fotochest

Development Team
================

* Derek Stegelman - Lead Developer ([http://derek.stegelman.com](http://derek.stegelman.com))
* Lindy Stegelman - QA/Design Critic ([http://blog.stegelman.com](http://blog.stegelman.com))

Platform
========

Python/Django

Docs
====

http://docs.fotochest.com/


