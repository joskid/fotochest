#Project details
PROJECT_ID = 'fotochest'
PROJECT_USER = ''
PROJECT_HOSTS = ['example.com']
